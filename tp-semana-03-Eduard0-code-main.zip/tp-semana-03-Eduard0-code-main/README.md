[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=20220297)
# Trabalho Prático - Semana 03

Dessa vez, vamos escolher uma proposta de projeto para trabalhar.

Nessa atividade, você deverá montar a página inicial do projeto escolhido, a organização do HTML aplicando semântica correta e uso aprimorado do CSS. Leia o enunciado completo no Canvas para mais detalhes.

**IMPORTANTE:** Você deve trabalhar e alterar apenas arquivos dentro da pasta **`public`**. Deixe todos os demais arquivos e pastas desse repositório inalterados. **PRESTE MUITA ATENÇÃO NISSO.**

## Informações Gerais

- Nome: Eduardo Costa Silva
- Matricula: 903137
- Proposta de projeto escolhida: 1. Pessoas e Produções.
- Breve descrição sobre seu projeto: Uma página de notícias e descrições sobre as músicas do antigo grupo de rap "Odd Future", originalmente chamado de "Odd Future Wolf Gang Kill Them All", o grupo se separou ao longo do tempo, então o meu objetivo é juntar todas as informações sobre as músicas e interpretações das letras, a história dos artistas, a progressão da carreira deles e como estão atualmente.


## Print do(s) wireframe(s) criado

<<  COLOQUE A IMAGEM AQUI >>
![Foto do wireframe feito no Miro](/public/prints/Sem%20título(2).jpg)

## Print da home-page criada

<<  COLOQUE A IMAGEM AQUI >>
![Print da home-page criada, precisei tirar um pouco do zoom para caber direito](/public/prints/Screenshot_1.png)
